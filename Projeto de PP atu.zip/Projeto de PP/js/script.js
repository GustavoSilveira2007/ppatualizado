document.addEventListener('DOMContentLoaded', function() {
    const deliveryForm = document.getElementById('delivery-form');
    const deliveryHistory = document.getElementById('delivery-history');

    deliveryForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const cpf = document.getElementById('cpf').value;
        const destino = document.getElementById('destino').value;
        const horario = document.getElementById('horario').value;

        const deliveryItem = document.createElement('li');
        deliveryItem.innerHTML = `<strong>CPF do Motorista:</strong> ${cpf}<br>
                                  <strong>Destino:</strong> ${destino}<br>
                                  <strong>Horário da Descarga:</strong> ${horario}`;
        
        deliveryHistory.appendChild(deliveryItem);
        deliveryForm.reset();
    });
});


